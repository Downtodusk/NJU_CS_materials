/*
 * semantic.h - Header file for semantic analysis module.
 * Declares data structures and function prototypes used for
 * symbol table management, type checking, and semantic processing.
 */

#ifndef SEMANTIC_H
#define SEMANTIC_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "tree.h"

/** ----- Type constants ----- */
#define TYPE_INT 1   ///< Integer type
#define TYPE_FLOAT 2 ///< Floating-point type

/** ----- Forward declarations ----- */
typedef struct Type_ Type_t;           ///< Type structure
typedef struct FieldList_ FieldList_t; ///< Field list for struct members and function parameters
typedef struct Structure_ Structure_t; ///< Structure type definition
typedef struct Function_ Function_t;   ///< Function type definition
typedef struct Symbol_ Symbol_t;       ///< Symbol for variable, function, etc.

/** ----- Enum for type kinds ----- */
typedef enum
{
    BASIC,      ///< Basic types: int, float
    ARRAY,      ///< Array type
    STRUCTURE,  ///< Anonymous struct or struct variable
    STRUCT_DEF, ///< Struct type definition
    FUNCTION    ///< Function type
} TypeKind;

/** ----- Core data structures ----- */
struct Type_
{
    TypeKind kind; ///< Type kind (e.g., BASIC, ARRAY)
    union
    {
        int basic; ///< BASIC: int or float
        struct
        {
            Type_t *elem;  ///< ARRAY: element type
            int dimension; ///< ARRAY: dimensions
        } array;
        Structure_t *structure; ///< STRUCTURE/STRUCT_DEF: structure type
        Function_t *func;       ///< FUNCTION: function type
    };
};

struct FieldList_
{
    char name[32];     ///< Field/parameter name
    Type_t *type;      ///< Field type
    int lineno;        ///< Line number of declaration
    FieldList_t *next; ///< Next field in list
};

struct Structure_
{
    char name[32];        ///< Struct name
    FieldList_t *members; ///< List of struct members
};

struct Function_
{
    char name[32];      ///< Function name
    Type_t *ret_type;   ///< Return type
    int lineno;         ///< Declaration line number
    FieldList_t *param; ///< Function parameters
};

struct Symbol_
{
    char name[32];       ///< Symbol name (variable, function, etc.)
    Type_t *type;        ///< Associated type
    int lineno;          ///< Line number of declaration
    Symbol_t *hashNext;  ///< Next symbol in hash table bucket
    Symbol_t *layerNext; ///< Next symbol in scope layer
};

/** ----- Type aliases ----- */
typedef Type_t *Type;           ///< Type alias for Type_t*
typedef FieldList_t *FieldList; ///< Type alias for FieldList_t*
typedef Structure_t *Structure; ///< Type alias for Structure_t*
typedef Function_t *Function;   ///< Type alias for Function_t*
typedef Symbol_t *Symbol;       ///< Type alias for Symbol_t*

/** ----- Core semantic analysis functions ----- */
void SemanticAnalysis(Node *node);        ///< Performs semantic analysis on the given syntax tree
void start_semantic_analysis(Node *root); ///< Starts the semantic analysis from the root node

/** ----- Declaration processing ----- */
void ExtDefList(Node *node);            ///< Processes the list of external definitions
void ExtDef(Node *node);                ///< Processes a single external definition
Type Specifier(Node *node);             ///< Processes a type specifier
void ExtDecList(Node *node, Type type); ///< Processes external declaration list

/** ----- Function processing ----- */
Function FunDec(Node *node);    ///< Processes a function declaration
FieldList VarList(Node *node);  ///< Processes a variable list
FieldList ParamDec(Node *node); ///< Processes a parameter declaration

/** ----- Structure processing ----- */
Type StructSpecifier(Node *node);  ///< Processes a structure specifier
char *OptTag(Node *node);          ///< Processes the optional tag of a structure
void check_struct(FieldList head); ///< Checks for duplicate field names in a structure

/** ----- Statement processing ----- */
void CompSt(Node *node, Type ret_type, char *funcName); ///< Processes a compound statement
void StmtList(Node *node, Type ret_type);               ///< Processes a list of statements
void Stmt(Node *node, Type ret_type);                   ///< Processes a single statement

/** ----- Expression processing ----- */
Type Exp(Node *node);       ///< Processes an expression
FieldList Args(Node *node); ///< Processes function arguments

/** ----- Definition processing ----- */
FieldList DefList(Node *node, bool in_struct);                      ///< Processes a list of definitions
FieldList Def(Node *node, bool in_struct);                          ///< Processes a single definition
FieldList DecList(Node *node, bool in_struct, Type type);           ///< Processes a list of declarations
FieldList Dec(Node *node, bool in_struct, Type type);               ///< Processes a single declaration
FieldList VarDec(Node *node, bool in_struct, Type type, int layer); ///< Processes a variable declaration

/** ----- Type system utilities ----- */
bool fieldEqual(FieldList list1, FieldList list2); ///< Checks if two field lists are equal
bool typeEqual(Type type1, Type type2);            ///< Checks if two types are equal

#endif // SEMANTIC_H
