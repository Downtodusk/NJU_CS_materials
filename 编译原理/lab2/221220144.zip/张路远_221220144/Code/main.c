#include <stdio.h>
#include "tree.h"
#include "semantic.h"

// External variables
extern FILE *yyin;
extern int Aerrors;
extern int Berrors;

// Function prototypes
int yyrestart(FILE *f);
int yyparse();

// Global variables
Node *root = NULL;

/**
 * @brief Main entry point of the program.
 *
 * This function reads the file specified in the command-line argument,
 * parses it using the lexer and parser, and then performs semantic analysis
 * if there are no errors in the parsing process.
 *
 * @param argc Number of command-line arguments.
 * @param argv Array of command-line argument strings.
 * @return int Exit status: 1 if no file is provided, 0 on success.
 */
int main(int argc, char **argv)
{
    // Check if the file argument is provided
    if (argc <= 1)
    {
        return 1;
    }

    // Open the file for reading
    FILE *f = fopen(argv[1], "r");
    if (!f)
    {
        printf("Fail to open file");
        return 0;
    }

    // Restart the lexer with the opened file
    yyrestart(f);

    // Parse the input file
    yyparse();

    // Perform semantic analysis if no errors were found
    if (!(Aerrors + Berrors))
    {
        start_semantic_analysis(root);
    }

    return 0;
}
