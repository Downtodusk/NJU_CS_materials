#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tree.h"

/**
 * @brief Creates a new node for the syntax tree.
 *
 * This function allocates memory for a new node, initializes its fields, and
 * links the child nodes as siblings.
 *
 * @param name The name of the node.
 * @param state The type of the node (e.g., identifier, integer).
 * @param yylineno The line number where the node was found.
 * @param child_num The number of child nodes.
 * @param ... The child nodes to be linked to this node.
 * @return Node* The newly created node.
 */
Node *createNode(char *name, NODE_TYPE state, int yylineno, int child_num, ...)
{
    Node *node = (Node *)malloc(sizeof(Node));

    if (node == NULL)
    {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    // Initialize node attributes
    node->name = (char *)malloc(sizeof(char) * (strlen(name) + 1));
    strcpy(node->name, name);
    node->type = state;
    node->yylineno = yylineno;
    node->child_num = child_num;
    node->first_child = NULL;
    node->next_sibling = NULL;

    // Return early if the node has no children
    if (node->type == NODE_TYPE_NULL || node->child_num == 0)
    {
        return node;
    }

    // Handle variable-length arguments for child nodes
    va_list param;
    va_start(param, child_num);
    Node *prev = NULL;

    for (int i = 0; i < child_num; i++)
    {
        Node *child = va_arg(param, Node *);
        if (child == NULL)
        {
            fprintf(stderr, "Child node is NULL at level %d\n", i);
            continue;
        }

        // Set the first child or link subsequent children as siblings
        if (i == 0)
        {
            node->first_child = child;
        }
        else if (prev != NULL)
        {
            prev->next_sibling = child;
        }
        prev = child;
    }

    va_end(param);

    return node;
}

/**
 * @brief Checks if all nodes in the subtree are of type NULL.
 *
 * This function recursively checks whether the node and all its children
 * are of type NODE_TYPE_NULL.
 *
 * @param node The node to check.
 * @return bool True if all nodes are NULL, false otherwise.
 */
bool CHECK_ALL_NULL(Node *node)
{
    if (node == NULL)
        return true;
    if (node->type != NODE_TYPE_NULL)
        return false;

    Node *child = node->first_child;
    while (child != NULL)
    {
        if (!CHECK_ALL_NULL(child))
            return false; // Found a non-NULL child
        child = child->next_sibling;
    }
    return true;
}

/**
 * @brief Prints the syntax tree in a human-readable format.
 *
 * This function recursively prints the syntax tree, starting from the given node.
 * It prints the node type and value, and recursively prints child nodes at each level.
 *
 * @param node The root node of the syntax tree.
 * @param level The current level in the tree (used for indentation).
 */
void print_syntax_tree(Node *node, int level)
{
    if (node == NULL)
        return;

    // Print the node if it contains non-NULL values
    if (!CHECK_ALL_NULL(node))
    {
        for (int i = 0; i < level; i++)
        {
            printf("  ");
        }

        switch (node->type)
        {
        case NODE_TYPE_INT:
            printf("INT: %d", node->value.ival);
            break;
        case NODE_TYPE_FLOAT:
            printf("FLOAT: %lf", node->value.fval);
            break;
        case NODE_TYPE_ID:
            printf("ID: %s", node->value.str);
            break;
        case NODE_TYPE_TYPE:
            printf("TYPE: %s", node->value.str);
            break;
        case NODE_TYPE_NORMAL:
            printf("%s (%d)", node->name, node->yylineno);
            break;
        case NODE_TYPE_TOKEN:
            printf("%s", node->name);
            break;
        default:
            break;
        }
        printf("\n");

        // Recursively print the child nodes
        Node *child = node->first_child;
        while (child != NULL)
        {
            print_syntax_tree(child, level + 1);
            child = child->next_sibling;
        }
    }
    else
    {
        // Set the type to NULL if the entire subtree is NULL
        node->type = NODE_TYPE_NULL;
    }
}
