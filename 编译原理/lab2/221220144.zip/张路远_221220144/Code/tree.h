#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <stdbool.h>

// Forward declaration for external variables and types
extern int yylineno;
typedef struct Node Node;

// Enum representing different node types in the syntax tree
typedef enum NODE_TYPE NODE_TYPE;

#ifndef TREE_H_
#define TREE_H_

// Enum for node types
enum NODE_TYPE
{
    NODE_TYPE_NORMAL, ///< Normal node type
    NODE_TYPE_NULL,   ///< Null node type
    NODE_TYPE_INT,    ///< Integer node type
    NODE_TYPE_FLOAT,  ///< Float node type
    NODE_TYPE_ID,     ///< Identifier node type
    NODE_TYPE_TYPE,   ///< Type node
    NODE_TYPE_TOKEN   ///< Token node type
};

// Structure representing a node in the syntax tree
struct Node
{
    char *name;     ///< Name of the node (e.g., "int", "id")
    int yylineno;   ///< Line number where the node was found
    int child_num;  ///< Number of child nodes
    NODE_TYPE type; ///< Type of the node (e.g., NODE_TYPE_INT)
    union
    {
        int ival;     ///< Integer value (if type is NODE_TYPE_INT)
        float fval;   ///< Float value (if type is NODE_TYPE_FLOAT)
        char str[32]; ///< String value (if type is NODE_TYPE_ID or NODE_TYPE_TYPE)
    } value;
    Node *first_child;  ///< Pointer to the first child node
    Node *next_sibling; ///< Pointer to the next sibling node
};

#endif // TREE_H_

// Function prototypes
Node *createNode(char *name, NODE_TYPE state, int yylineno, int child_num, ...);
bool CHECK_ALL_NULL(Node *node);
void print_syntax_tree(Node *node, int index);
