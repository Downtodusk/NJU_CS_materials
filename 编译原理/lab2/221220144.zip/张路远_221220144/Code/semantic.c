/*
 * semantic.c - Semantic analysis module for a compiler.
 * This file implements symbol table management, type checking,
 * and semantic analysis of the syntax tree.
 */

#include "semantic.h"
#include <assert.h>

#define TABLE_SIZE 200

// Symbol table and layer stack definitions
Symbol symbol_table[TABLE_SIZE];
Symbol layersHead;

// Print a semantic error with formatted message
void print_semantic_error(int error_type, int lineno, const char *msg, ...)
{
    va_list args;
    va_start(args, msg);
    printf("Error type %d at line %d: ", error_type, lineno);
    vprintf(msg, args);
    printf("\n");
    va_end(args);
}

// Count the number of children in a node
int count_children(Node *node)
{
    int count = 0;
    for (Node *child = node->first_child; child; child = child->next_sibling)
    {
        count++;
    }
    return count;
}

// PJW hash function for symbol names
unsigned int PJW_hash(char *name)
{
    unsigned int val = 0, i;
    for (; *name; ++name)
    {
        val = (val << 2) + *name;
        if ((i = val & ~0x3fff))
        {
            val = (val ^ (i >> 12)) & 0x3fff;
        }
    }
    return val % TABLE_SIZE;
}

// Initialize the symbol table and global scope
void init_symbol_table()
{
    for (int i = 0; i < TABLE_SIZE; i++)
    {
        symbol_table[i] = NULL;
    }

    layersHead = (Symbol)malloc(sizeof(Symbol_t));
    layersHead->hashNext = NULL;
    layersHead->layerNext = NULL;

    Symbol globalLayer = (Symbol)malloc(sizeof(Symbol_t));
    globalLayer->hashNext = NULL;
    globalLayer->layerNext = NULL;
    layersHead->hashNext = globalLayer;
}

// Create a new symbol with a given name, type, and line number
Symbol create_symbol(char *str, Type type, int lineno)
{
    Symbol sym = (Symbol)malloc(sizeof(Symbol_t));
    strcpy(sym->name, str);
    sym->type = type;
    sym->lineno = lineno;
    sym->hashNext = NULL;
    return sym;
}

// Insert a symbol into the symbol table and current scope
void insert_symbol(Symbol sym)
{
    unsigned int index = PJW_hash(sym->name);

    // Insert into hash table
    Symbol tail = symbol_table[index];
    symbol_table[index] = sym;
    sym->hashNext = tail;

    // Insert into current scope
    Symbol curLayer = layersHead->hashNext;
    tail = curLayer->layerNext;
    curLayer->layerNext = sym;
    sym->layerNext = tail;
}

// Search for a symbol in the entire symbol table
Symbol search_symbol_all(char *str)
{
    unsigned int index = PJW_hash(str);
    Symbol sym = symbol_table[index];
    while (sym != NULL)
    {
        if (strcmp(sym->name, str) == 0)
        {
            break;
        }
        sym = sym->hashNext;
    }
    return sym;
}

// Search for a symbol in the current scope only
Symbol search_symbol_layer(char *name)
{
    Symbol currentLayer = layersHead->hashNext;
    Symbol symbol = currentLayer->layerNext;
    while (symbol != NULL)
    {
        if (strcmp(symbol->name, name) == 0)
        {
            break;
        }
        symbol = symbol->layerNext;
    }
    return symbol;
}

// Search specifically for a function symbol
Symbol search_symbol_func(char *name)
{
    unsigned int hash = PJW_hash(name);
    Symbol tmp = symbol_table[hash];
    while (tmp != NULL)
    {
        if (strcmp(tmp->name, name) == 0 && tmp->type->kind == FUNCTION)
        {
            break;
        }
        tmp = tmp->hashNext;
    }
    return tmp;
}

// Delete a single symbol from the symbol table
void del_single_symbol(char *name)
{
    unsigned int hash = PJW_hash(name);
    Symbol pre = NULL;
    Symbol tmp = symbol_table[hash];
    while (tmp != NULL)
    {
        if (strcmp(tmp->name, name) == 0)
        {
            break;
        }
        pre = tmp;
        tmp = tmp->hashNext;
    }
    if (tmp != NULL)
    {
        if (pre == NULL)
        {
            symbol_table[hash] = tmp->hashNext;
        }
        else
        {
            pre->hashNext = tmp->hashNext;
        }
    }
}

// Create a new scope for declarations
void enter_layer()
{
    Symbol currentLayer = (Symbol)malloc(sizeof(Symbol_t));
    currentLayer->hashNext = NULL;
    currentLayer->layerNext = NULL;
    Symbol tail = layersHead->hashNext;
    layersHead->hashNext = currentLayer;
    currentLayer->hashNext = tail;
}

// Exit the current scope, removing symbols declared in it
void exit_layer()
{
    Symbol currentLayer = layersHead->hashNext;
    layersHead->hashNext = currentLayer->hashNext;
    Symbol symbol = currentLayer->layerNext;
    while (symbol != NULL)
    {
        del_single_symbol(symbol->name);
        symbol = symbol->layerNext;
    }
}

// Compare two field lists for semantic equivalence
bool fieldEqual(FieldList list1, FieldList list2)
{
    if (!list1 && !list2)
        return true;
    if (!list1 || !list2)
        return false;
    return typeEqual(list1->type, list2->type) && fieldEqual(list1->next, list2->next);
}

// Compare two types for semantic equivalence
bool typeEqual(Type type1, Type type2)
{
    if (!type1 || !type2)
        return true;
    if (type1->kind != type2->kind)
        return false;

    switch (type1->kind)
    {
    case BASIC:
        return type1->basic == type2->basic;
    case ARRAY:
        return typeEqual(type1->array.elem, type2->array.elem) &&
               type1->array.dimension == type2->array.dimension;
    case FUNCTION:
        return !strcmp(type1->func->name, type2->func->name) &&
               typeEqual(type1->func->ret_type, type2->func->ret_type) &&
               fieldEqual(type1->func->param, type2->func->param);
    default:
        return !strcmp(type1->structure->name, type2->structure->name) &&
               fieldEqual(type1->structure->members, type2->structure->members);
    }
}

// Start semantic analysis from the root of the syntax tree
void start_semantic_analysis(Node *root)
{
    init_symbol_table();
    SemanticAnalysis(root);
}

// Recursively process the syntax tree for top-level definitions
void SemanticAnalysis(Node *node)
{
    if (node == NULL)
        return;
    ExtDefList(node->first_child);
}

// Handle a list of external definitions (e.g., global declarations)
void ExtDefList(Node *node)
{
    if (node->first_child != NULL)
    {
        ExtDef(node->first_child);
        ExtDefList(node->first_child->next_sibling);
    }
}

// Handle a single external definition (e.g., function, variable, struct)
void ExtDef(Node *node)
{
    Type type = Specifier(node->first_child);
    if (!type)
        return;

    Node *sibling = node->first_child->next_sibling;
    if (strcmp(sibling->name, "SEMI") == 0)
    {
        // Only a type declaration, e.g., int;
        return;
    }

    if (strcmp(sibling->name, "ExtDecList") == 0)
    {
        // Variable declarations, e.g., int a, b;
        ExtDecList(sibling, type);
        return;
    }

    // Function definition
    assert(strcmp(sibling->name, "FunDec") == 0);
    assert(strcmp(sibling->next_sibling->name, "CompSt") == 0);

    Function func = FunDec(sibling);
    func->ret_type = type;

    Type func_type = (Type)malloc(sizeof(Type_t));
    func_type->kind = FUNCTION;
    func_type->func = func;

    Symbol sym = search_symbol_all(func->name);
    if (sym == NULL)
    {
        Symbol newSymbol = create_symbol(func->name, func_type, func->lineno);
        insert_symbol(newSymbol);
        enter_layer();
        CompSt(sibling->next_sibling, func->ret_type, func->name);
        exit_layer();
    }
    else
    {
        if (sym->type->kind != FUNCTION)
        {
            print_semantic_error(4, node->yylineno, "name repeat");
        }
        else
        {
            print_semantic_error(4, node->yylineno, "function repeat define: %d", sym->lineno);
        }
    }
}

// Handle a specifier (basic type or structure)
Type Specifier(Node *node)
{
    if (strcmp(node->first_child->name, "TYPE") == 0)
    {
        Type type = (Type)malloc(sizeof(Type_t));
        type->kind = BASIC;
        char *str = node->first_child->value.str;
        type->basic = (strcmp(str, "int") == 0) ? TYPE_INT : TYPE_FLOAT;
        return type;
    }
    return StructSpecifier(node->first_child);
}

// Handle a list of external variable declarations
void ExtDecList(Node *node, Type type)
{
    VarDec(node->first_child, false, type, 0);
    if (count_children(node) == 3)
    {
        ExtDecList(node->first_child->next_sibling->next_sibling, type);
    }
}

// Handle a function declaration and its parameter list
Function FunDec(Node *node)
{
    Function func = (Function)malloc(sizeof(Function_t));
    strcpy(func->name, node->first_child->value.str);
    func->lineno = node->yylineno;
    func->param = NULL;

    if (count_children(node) == 3)
    {
        func->param = NULL;
    }
    else
    {
        enter_layer();
        func->param = VarList(node->first_child->next_sibling->next_sibling);
        exit_layer();
    }
    return func;
}

// Handle structure type definitions and references
Type StructSpecifier(Node *node)
{
    Type type = (Type)malloc(sizeof(Type_t));
    type->kind = STRUCTURE;

    if (count_children(node) == 2)
    {
        // Reference to a previously defined struct
        Node *Tag = node->first_child->next_sibling;
        char *str = Tag->first_child->value.str;
        Symbol sym = search_symbol_all(str);
        if (sym == NULL || sym->type->kind != STRUCT_DEF)
        {
            print_semantic_error(17, node->yylineno, "undefined struct");
            return NULL;
        }
        type->structure = sym->type->structure;
    }
    else
    {
        // Struct definition (with or without tag)
        char *str = OptTag(node->first_child->next_sibling);
        if (strcmp(str, "") != 0)
        {
            Symbol sym = search_symbol_all(str);
            if (sym != NULL)
            {
                print_semantic_error(16, node->yylineno, "Duplicated struct name");
                free(str);
                return NULL;
            }
            Type new_type = (Type)malloc(sizeof(Type_t));
            new_type->kind = STRUCT_DEF;
            new_type->structure = (Structure)malloc(sizeof(Structure_t));
            strcpy(new_type->structure->name, str);
            new_type->structure->members = DefList(node->first_child->next_sibling->next_sibling->next_sibling, true);
            check_struct(new_type->structure->members);
            Symbol newSymbol = create_symbol(str, new_type, node->yylineno);
            insert_symbol(newSymbol);
            type->structure = newSymbol->type->structure;
            free(str);
        }
        else
        {
            type->structure = (Structure)malloc(sizeof(Structure_t));
            strcpy(type->structure->name, str);
            enter_layer();
            type->structure->members = DefList(node->first_child->next_sibling->next_sibling->next_sibling, true);
            exit_layer();
            check_struct(type->structure->members);
        }
    }
    return type;
}

// Get optional struct tag (name) or empty string
char *OptTag(Node *node)
{
    char *name = (char *)malloc(sizeof(char) * 32);
    if (node->type == NODE_TYPE_NULL)
    {
        strcpy(name, "");
    }
    else
    {
        strcpy(name, node->first_child->value.str);
    }
    return name;
}

// Handle a list of parameter declarations
FieldList VarList(Node *node)
{
    FieldList list = ParamDec(node->first_child);
    if (count_children(node) == 3)
    {
        if (list == NULL)
        {
            list = VarList(node->first_child->next_sibling->next_sibling);
        }
        else
        {
            list->next = VarList(node->first_child->next_sibling->next_sibling);
        }
    }
    return list;
}

// Handle a single parameter declaration
FieldList ParamDec(Node *node)
{
    Type type = Specifier(node->first_child);
    if (type == NULL)
    {
        return NULL;
    }
    return VarDec(node->first_child->next_sibling, false, type, 0);
}

// Handle a list of definitions (e.g., in structs or blocks)
FieldList DefList(Node *node, bool in_struct)
{
    if (node->type == NODE_TYPE_NULL)
    {
        return NULL;
    }

    FieldList list = Def(node->first_child, in_struct);
    if (list == NULL)
    {
        return DefList(node->first_child->next_sibling, in_struct);
    }

    FieldList ptr = list;
    while (ptr->next != NULL)
    {
        ptr = ptr->next;
    }
    ptr->next = DefList(node->first_child->next_sibling, in_struct);
    return list;
}

// Handle a single definition (e.g., a type and a list of declarators)
FieldList Def(Node *node, bool in_struct)
{
    Type type = Specifier(node->first_child);
    if (type == NULL)
    {
        return NULL;
    }
    return DecList(node->first_child->next_sibling, in_struct, type);
}

// Handle a list of declarators (variables or fields)
FieldList DecList(Node *node, bool in_struct, Type type)
{
    FieldList list = Dec(node->first_child, in_struct, type);
    if (count_children(node) > 1)
    {
        if (list == NULL)
        {
            return DecList(node->first_child->next_sibling->next_sibling, in_struct, type);
        }
        FieldList ptr = list;
        while (ptr->next != NULL)
        {
            ptr = ptr->next;
        }
        ptr->next = DecList(node->first_child->next_sibling->next_sibling, in_struct, type);
    }
    return list;
}

// Handle a single declarator
FieldList Dec(Node *node, bool in_struct, Type type)
{
    FieldList list = VarDec(node->first_child, in_struct, type, 0);
    if (in_struct && count_children(node) == 3)
    {
        print_semantic_error(15, node->yylineno, "initialize member in struct definition");
    }
    if (list != NULL && count_children(node) == 3)
    {
        Type right = Exp(node->first_child->next_sibling->next_sibling);
        if (!typeEqual(list->type, right))
        {
            print_semantic_error(5, node->yylineno, "type mismatched");
        }
    }
    return list;
}

// Handle a variable declaration, including arrays and conflict checking
FieldList VarDec(Node *node, bool in_struct, Type type, int layer)
{
    char *str = node->first_child->value.str;

    // Simple identifier
    if (count_children(node) == 1)
    {
        Symbol sym = search_symbol_layer(str);
        Symbol symA = search_symbol_all(str);

        if (sym != NULL || (symA != NULL && symA->type->kind == STRUCT_DEF))
        {
            print_semantic_error(3, node->yylineno, "var name conflict (Var: %s)", symA->name);
            if (!in_struct)
            {
                return NULL;
            }
        }

        FieldList list = (FieldList)malloc(sizeof(FieldList_t));
        strcpy(list->name, str);

        // Handle array dimensions
        list->type = (layer == 0) ? type : ({
            Type arr_type = (Type)malloc(sizeof(Type_t));
            arr_type->kind = ARRAY;
            arr_type->array.elem = type;
            arr_type->array.dimension = layer;
            arr_type;
        });
        list->lineno = -1;
        list->next = NULL;

        if (sym != NULL && !in_struct)
        {
            print_semantic_error(3, node->yylineno, "var name conflict");
            if (!in_struct)
            {
                return NULL;
            }
        }

        if (sym == NULL && !in_struct)
        {
            Symbol newSymbol = create_symbol(str, list->type, node->yylineno);
            insert_symbol(newSymbol);
        }
        else
        {
            list->lineno = node->yylineno; // For struct members
        }
        return list;
    }

    // Handle array type: VarDec LB INT RB
    return VarDec(node->first_child, in_struct, type, layer + 1);
}

// Handle a compound statement block with declarations and statements
void CompSt(Node *node, Type ret_type, char *funcName)
{
    if (funcName != NULL)
    {
        Symbol sym = search_symbol_func(funcName);
        FieldList params = sym->type->func->param;
        while (params != NULL)
        {
            Symbol parm = (Symbol)malloc(sizeof(Symbol_t));
            strcpy(parm->name, params->name);
            parm->type = params->type;
            insert_symbol(parm);
            params = params->next;
        }
    }
    DefList(node->first_child->next_sibling, false);
    StmtList(node->first_child->next_sibling->next_sibling, ret_type);
}

// Handle a list of statements
void StmtList(Node *node, Type ret_type)
{
    if (node->type == NODE_TYPE_NULL)
    {
        return;
    }
    Stmt(node->first_child, ret_type);
    StmtList(node->first_child->next_sibling, ret_type);
}

// Handle a single statement (e.g., return, while, if, block, expression)
void Stmt(Node *node, Type ret_type)
{
    Node *first = node->first_child;
    if (strcmp(first->name, "Exp") == 0)
    {
        Exp(first);
    }
    else if (strcmp(first->name, "CompSt") == 0)
    {
        enter_layer();
        CompSt(first, ret_type, NULL);
        exit_layer();
    }
    else if (strcmp(first->name, "RETURN") == 0)
    {
        Type exp_type = Exp(first->next_sibling);
        if (!typeEqual(exp_type, ret_type))
        {
            print_semantic_error(8, node->yylineno, "error return type");
        }
    }
    else if (strcmp(first->name, "WHILE") == 0)
    {
        Exp(first->next_sibling->next_sibling);
        Stmt(first->next_sibling->next_sibling->next_sibling->next_sibling, ret_type);
    }
    else
    {
        // IF or IF-ELSE
        Exp(first->next_sibling->next_sibling);
        Stmt(first->next_sibling->next_sibling->next_sibling->next_sibling, ret_type);
        if (count_children(node) == 7)
        {
            Stmt(first->next_sibling->next_sibling->next_sibling->next_sibling->next_sibling->next_sibling, ret_type);
        }
    }
}

// Analyze an expression and return its type
Type Exp(Node *node)
{
    Node *first = node->first_child;

    // ID or function call
    if (strcmp(first->name, "ID") == 0)
    {
        char *str = first->value.str;
        Symbol sym = search_symbol_all(str);

        if (count_children(node) == 1)
        {
            if (sym == NULL)
            {
                print_semantic_error(1, node->yylineno, "undefined variable '%s'", str);
                return NULL;
            }
            return sym->type;
        }
        else
        {
            if (sym == NULL)
            {
                print_semantic_error(2, node->yylineno, "undefined function '%s'", str);
                return NULL;
            }
            if (sym->type->kind != FUNCTION)
            {
                print_semantic_error(11, node->yylineno, "'%s' is not a function", str);
                return NULL;
            }
            FieldList args = (count_children(node) == 4) ? Args(first->next_sibling->next_sibling) : NULL;
            FieldList params = sym->type->func->param;
            if (!fieldEqual(args, params))
            {
                print_semantic_error(9, node->yylineno, "argument mismatch");
            }
            return sym->type->func->ret_type;
        }
    }

    // Constants
    if (strcmp(first->name, "INT") == 0 || strcmp(first->name, "FLOAT") == 0)
    {
        Type type = (Type)malloc(sizeof(Type_t));
        type->kind = BASIC;
        type->basic = (strcmp(first->name, "INT") == 0) ? TYPE_INT : TYPE_FLOAT;
        return type;
    }

    // Parenthesized expression
    if (strcmp(first->name, "LP") == 0)
    {
        return Exp(first->next_sibling);
    }

    // Unary operators
    if (strcmp(first->name, "MINUS") == 0 || strcmp(first->name, "NOT") == 0)
    {
        Type exp_type = Exp(first->next_sibling);
        if (exp_type != NULL)
        {
            if (strcmp(first->name, "MINUS") == 0 && exp_type->kind != BASIC)
            {
                print_semantic_error(7, node->yylineno, "invalid use of unary minus");
                return NULL;
            }
            else if (strcmp(first->name, "NOT") == 0 && (exp_type->kind != BASIC || exp_type->basic != TYPE_INT))
            {
                print_semantic_error(7, node->yylineno, "'!' requires integer type");
                return NULL;
            }
        }
        return exp_type;
    }

    // Binary operators
    Node *second = first->next_sibling;
    if (strcmp(second->name, "ASSIGNOP") == 0)
    {
        Type right = Exp(second->next_sibling);
        Type left = Exp(first);

        Node *left_child = first;
        if (!((count_children(left_child) == 1 && strcmp(left_child->first_child->name, "ID") == 0) ||
              (count_children(left_child) == 3 && strcmp(left_child->first_child->next_sibling->name, "DOT") == 0) ||
              (count_children(left_child) == 4 && strcmp(left_child->first_child->next_sibling->name, "LB") == 0)))
        {
            print_semantic_error(6, node->yylineno, "left side of assignment must be a variable");
            return NULL;
        }
        if (left && right && (!typeEqual(left, right) || left->kind == FUNCTION))
        {
            print_semantic_error(5, node->yylineno, "type mismatch in assignment");
            return NULL;
        }
        return left;
    }

    if (strcmp(second->name, "AND") == 0 || strcmp(second->name, "OR") == 0)
    {
        Type left = Exp(first);
        Type right = Exp(second->next_sibling);
        if (left && right && left->kind == BASIC && right->kind == BASIC &&
            left->basic == TYPE_INT && right->basic == TYPE_INT)
        {
            return left;
        }
        print_semantic_error(7, node->yylineno, "logical operators require INT operands");
        return NULL;
    }

    if (strcmp(second->name, "RELOP") == 0 ||
        strcmp(second->name, "PLUS") == 0 || strcmp(second->name, "MINUS") == 0 ||
        strcmp(second->name, "STAR") == 0 || strcmp(second->name, "DIV") == 0)
    {
        Type left = Exp(first);
        Type right = Exp(second->next_sibling);
        if (left == NULL || right == NULL)
            return NULL;
        if (left->kind != BASIC || right->kind != BASIC || left->basic != right->basic)
        {
            print_semantic_error(7, node->yylineno, "invalid arithmetic or relational expression");
            return NULL;
        }
        if (strcmp(second->name, "RELOP") == 0)
        {
            Type type = (Type)malloc(sizeof(Type_t));
            type->kind = BASIC;
            type->basic = TYPE_INT;
            return type;
        }
        return left;
    }

    if (strcmp(second->name, "DOT") == 0)
    {
        Type t = Exp(first);
        if (t == NULL)
            return NULL;
        if (t->kind != STRUCTURE && t->kind != STRUCT_DEF)
        {
            print_semantic_error(13, node->yylineno, "accessing field of non-struct type");
            return NULL;
        }
        char *field_name = second->next_sibling->value.str;
        FieldList f = t->structure->members;
        while (f != NULL)
        {
            if (strcmp(f->name, field_name) == 0)
                return f->type;
            f = f->next;
        }
        print_semantic_error(14, node->yylineno, "field '%s' not found", field_name);
        return NULL;
    }

    if (strcmp(second->name, "LB") == 0)
    {
        Type base = Exp(first);
        Type index = Exp(second->next_sibling);
        if (base == NULL || index == NULL)
            return NULL;
        if (base->kind != ARRAY)
        {
            print_semantic_error(10, node->yylineno, "indexing non-array type");
            return NULL;
        }
        if (index->kind != BASIC || index->basic != TYPE_INT)
        {
            print_semantic_error(12, node->yylineno, "array index must be INT");
            return base->array.elem;
        }
        if (base->array.dimension == 1)
            return base->array.elem;
        Type t = (Type)malloc(sizeof(Type_t));
        t->kind = ARRAY;
        t->array.elem = base->array.elem;
        t->array.dimension = base->array.dimension - 1;
        return t;
    }

    return NULL;
}

// Analyze function arguments as a FieldList
FieldList Args(Node *node)
{
    FieldList list = (FieldList)malloc(sizeof(FieldList_t));
    list->type = Exp(node->first_child);
    list->next = (count_children(node) == 3) ? Args(node->first_child->next_sibling->next_sibling) : NULL;
    return list;
}

// Check for duplicated field names in a struct definition
void check_struct(FieldList head)
{
    FieldList outer = head;
    while (outer != NULL)
    {
        FieldList inner = outer->next;
        FieldList pre_inner = outer;
        while (inner != NULL)
        {
            if (strcmp(outer->name, inner->name) == 0)
            {
                print_semantic_error(15, inner->lineno, "duplicated field '%s'", inner->name);
                pre_inner->next = inner->next;
                inner = pre_inner->next;
            }
            else
            {
                pre_inner = inner;
                inner = inner->next;
            }
        }
        outer = outer->next;
    }
}
